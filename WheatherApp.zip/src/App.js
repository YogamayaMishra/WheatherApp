import React from "react";
import "./styles.css";
export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      temp: 0,
      lat: 0,
      lon: 0,
      wind: 0,
      humidity: 0,
      feelslike: 0,
      city: "Bangalore",
      weatherType: 0
    };
  }

  componentDidMount() {
    this.getData("Bangalore");
  }
  getData = (value) => {
    fetch(
      "https://api.openweathermap.org/data/2.5/forecast?q=" +
        value +
        "&appid=38a5b56b0866414c782c2c64f4861e9c"
    )
      .then((response) => response.json())
      .then((json) => {
        this.setState({
          temp: json.list[0].main.temp,
          lat: json.city.coord.lat,
          lon: json.city.coord.lon,
          wind: json.list[0].wind.speed,
          humidity: json.list[0].main.humidity,
          feelslike: json.list[0].main.feels_like,
          city: value,
          weatherType: json.list[0].weather[0].main
        });
      })
      .catch((error) => {
        console.error(error);
      });
  };
  // changeCity = (value) => {
  //   this.setState({
  //     city: value
  //   });
  // };

  render() {
    return (
      <div>
        <h1>WEATHER APP</h1>
        <div
          className="city"
          onClick={() => {
            this.getData("Bangalore");
          }}
        >
          Bangalore{" "}
        </div>
        <div
          className="city"
          onClick={() => {
            this.getData("Delhi");
          }}
        >
          Delhi{" "}
        </div>
        <div
          className="city"
          onClick={() => {
            this.getData("Mumbai");
          }}
        >
          Mumbai{" "}
        </div>

        <div className="container">
          {/*Weather Component*/}
          <div className="weather">
            <div className="cointainer-inner ">
              {/*Left side Component*/}
              <div className="content-inner left-side ">
                <span className="primary">{this.state.city}</span>
                <br />
                <span className="secondary">as of {new Date().toString()}</span>
                <br />
                <span className="temp">{this.state.temp}</span>
                <br />
                <span className="primary">Haze</span>
                <br />
                <span className="secondary">42% chance of rain</span>
                <br />
              </div>
              {/*RIght side Component*/}
              <div className="content-inner right-side">
                <span className="primary">{this.state.humidity}</span>
                <br />
                <span className="secondary">Humidity</span>
                <br /> <br />
                <span className="primary">{this.state.feelslike}</span>
                <br />
                <span className="secondary">Feels like</span>
                <br />
                <br />
                <span className="primary">{this.state.wind}</span>
                <br />
                <span className="secondary">Wind</span>
              </div>
            </div>
          </div>
          {/*Details Component*/}
          <div className="details">
            <div className="cointainer-inner ">
              {/*Left side Component*/}
              <div className="content-inner  ">
                <br /> <br /> <br /> <br />
                <span className="primary">15-10-2021 12:11</span>
                <br />
                <span className="secondary">Local time</span>
                <br /> <br /> <br />
                <span className="primary">12.983, 77.583</span>
                <br />
                <span className="secondary">Co ordinates</span>
                <br /> <br />
              </div>
              {/*RIght side Component*/}
              <div className="content-inner ">
                <br /> <br />
                <br />
                <span className="primary">
                  {" "}
                  {this.state.lat},{this.state.long}
                </span>
                <br />
                <span className="secondary">Location</span>
                <br /> <br />
                <br /> <br />
                <span className="primary">Asia/Kolkata</span>
                <br />
                <span className="secondary">Time Zone</span>
                <br /> <br />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
